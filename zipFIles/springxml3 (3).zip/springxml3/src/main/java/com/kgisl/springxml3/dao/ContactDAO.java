package com.kgisl.springxml3.dao;

import java.util.List;

import com.kgisl.springxml3.model.Contact;

public interface ContactDAO {
     
    public void saveOrUpdate(Contact contact);
     
    public void delete(int contactId);
     
    public Contact get(int contactId);
     
    public List<Contact> list();

    public String greeting();
}