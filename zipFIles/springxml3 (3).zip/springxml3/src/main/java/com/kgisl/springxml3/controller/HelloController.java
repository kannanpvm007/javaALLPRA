package com.kgisl.springxml3.controller;

import com.kgisl.springxml3.dao.ContactDAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * HelloController
 */
@Controller
@RequestMapping("/hello")
public class HelloController {

    @Autowired
    private ContactDAO contactDAO;

    @RequestMapping(value = "/get", method = RequestMethod.GET)
    public String greet(Model model) {
        System.out.println(contactDAO);
        String attributeName = contactDAO.greeting();
        model.addAttribute("attributeName", attributeName);
        return "hello";
    }

}