package com.kgisl.springxml3.service;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * MyService
 */
@Component
@Scope("prototype")

public class MyService {

    
}